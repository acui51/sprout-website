import avSoundbites from "./arianaVenti";

const hoSoundbites = {
  rnb_chinese: {
    image: "",
    genre: "rnb",
    previous: [avSoundbites.pop_banana],
  },
  rnb_fuji: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rnb_vforvendetta: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rnb_lantern: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rnb_pelican: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rnb_lotus: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rnb_stars: {
    image: "",
    genre: "rnb",
    previous: [],
  },
  rock_pow: {
    image: "",
    genre: "rock",
    previous: [],
  },
  rock_pow: {
    image: "",
    genre: "rock",
    previous: [],
  },
  rock_storefront: {
    image: "",
    genre: "rock",
    previous: [],
  },
  rock_guitar: {
    image: "",
    genre: "rock",
    previous: [],
  },
  rock_cat: {
    image: "",
    genre: "rock",
    previous: [],
  },
  rock_sign: {
    image: "",
    genre: "rock",
    previous: [],
  },
  country_corona: {
    image: "",
    genre: "country",
    previous: [],
  },
  country_popart: {
    image: "",
    genre: "country",
    previous: [],
  },
  country_heart: {
    image: "",
    genre: "country",
    previous: [],
  },
  country_leaves: {
    image: "",
    genre: "country",
    previous: [],
  },
  country_sunset: {
    image: "",
    genre: "country",
    previous: [],
  },
};

export default hoSoundbites;
