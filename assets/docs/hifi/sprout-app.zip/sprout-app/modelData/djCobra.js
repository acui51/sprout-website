const djcSoundbites = {
  edm_blueorange: {
    image: "",
    genre: "edm",
    previous: [],
  },
  edm_skeleton: {
    image: "",
    genre: "edm",
    previous: [],
  },
  edm_monsters: {
    image: "",
    genre: "edm",
    previous: [],
  },
  edm_impala: {
    image: "",
    genre: "edm",
    previous: [],
  },
  edm_strobes: {
    image: "",
    genre: "edm",
    previous: [],
  },
  hiphop_strobes: {
    image: "",
    genre: "hip hop",
    previous: [],
  },
  hiphop_casettes: {
    image: "",
    genre: "hip hop",
    previous: [],
  },
  hiphop_space: {
    image: "",
    genre: "hip hop",
    previous: [],
  },
  hiphop_architecture: {
    image: "",
    genre: "hip hop",
    previous: [],
  },
  hiphop_ufo: {
    image: "",
    genre: "hip hop",
    previous: [],
  },
  pop_candy: {
    image: "",
    genre: "pop",
    previous: [],
  },
  pop_bwflowers: {
    image: "",
    genre: "pop",
    previous: [],
  },
  pop_rose: {
    image: "",
    genre: "pop",
    previous: [],
  },
  pop_flower: {
    image: "",
    genre: "pop",
    previous: [],
  },
  pop_strawberry: {
    image: "",
    genre: "pop",
    previous: [],
  },
};
