const avSoundbites = {
  pop_banana: {
    image: "",
    genre: "pop",
    previous: [], // soundbites[]
  },

  pop_cherry: {
    image: "",
    genre: "pop",
    previous: [], // soundbites[]
  },

  rnb_statue: {
    image: "",
    genre: "rnb",
    previous: [],
  },

  rnb_chinese: {
    image: "",
    genre: "rnb",
    previous: [],
  },

  rnb_plant: {
    image: "",
    genre: "rnb",
    previous: [],
  },

  pop_chair: {
    image: "",
    genre: "pop",
    previous: [],
  },

  pop_cat: {
    image: "",
    genre: "pop",
    previous: [],
  },

  pop_unicorn: {
    image: "",
    genre: "pop",
    previous: [],
  },
};

export default avSoundbites;
