# sprout-app

CS147 Final Project - HiFi Prototype

Technologies: React Native, Expo, Firebase

Run `yarn install` and `yarn start`

FOR CS147:

Unzip the .zip file and run `yarn install` and `yarn start`.
